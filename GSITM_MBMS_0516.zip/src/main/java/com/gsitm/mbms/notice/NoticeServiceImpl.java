package com.gsitm.mbms.notice;

/**
 * @주제 : 
 * @작성일 : 2019. 5. 16.
 * @작성자 : 조성윤
 */
public class NoticeServiceImpl implements NoticeService {

}
