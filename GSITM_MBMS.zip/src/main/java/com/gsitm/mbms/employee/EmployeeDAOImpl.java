package com.gsitm.mbms.employee;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

/**
 * @주제 : 
 * @작성일 : 2019. 5. 7.
 * @작성자 : 조성윤
 */
@Repository
public class EmployeeDAOImpl implements EmployeeDAO {
	@Inject
	private SqlSession sqlSession;
}
