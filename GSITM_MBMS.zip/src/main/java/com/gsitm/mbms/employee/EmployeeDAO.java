package com.gsitm.mbms.employee;

/**
 * @주제 : 
 * @작성일 : 2019. 5. 3.
 * @작성자 : 조성윤
 */
public interface EmployeeDAO {
	
}
