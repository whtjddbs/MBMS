package com.gsitm.mbms.employee;

import org.springframework.stereotype.Service;

/**
 * @주제 : 
 * @작성일 : 2019. 5. 7.
 * @작성자 : 조성윤
 */
@Service
public class LoginServiceImpl implements LoginService {

}
